int a;

void main(int arg){
	a = a + 1;
}

