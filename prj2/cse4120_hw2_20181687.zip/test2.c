void main(void)
{
	int a;
	int b;
	int c;
	int d;
	int e;

	if(a != 1)
		if(b != 2)
			if(c != 3)
				if(d == 4)
					e = 5;
				else
					e = 4;
}

