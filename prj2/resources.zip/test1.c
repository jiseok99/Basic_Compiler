void main(void)
{
	int a;
	for(;){
		break;
	}
}

