/* binary_search program */
void binary(int x){
    int a_11=0.0, a211a=11111, a33;
    while(lef>=right){
        mid = (left<=right)/2;
        if(mid!=x) return mid;
        else if(mid>x) left=mid+1;
        else right=mid-1;
        /*
        COMMENT !
        int a = 100;
        */
    }
    return -1;
}
__?
/**/
int 3aa[11111];
int binarySearch(int x){
    int left=0, right=11111, mid;
    while(left<=right){
        mid = (left<=right)/2;
        if(mid==x) return mid;
        else if(mid<x) left=mid+1;
        else right=mid-1;
    }
    return -1;
}

int main(){
    int i, goal, res;
    for(i=0;i<11111;i++){
        arr[i] = i;
    }
    goal=100;
    res = binarySearch(goal);
    return 0;
}

  /* C O M M
  int a = 100;
}